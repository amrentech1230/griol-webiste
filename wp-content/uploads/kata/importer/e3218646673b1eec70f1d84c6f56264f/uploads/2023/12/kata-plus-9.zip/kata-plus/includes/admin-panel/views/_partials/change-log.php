<?php

/**
 * Change Log.
 *
 * @author  ClimaxThemes
 * @package Kata Plus
 * @since   1.0.0
 */

// Don't load directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<pre>
	<!-- 1.2.9 -->
	<span class="version">1.2.9</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '17 Jun, 2023' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Update: WooCommerce Templates
		• Compatibility: Elementor 3.13.0
		• Compatibility: ShopPress
		• Fixed: Some minor issues
	</div>

	<!-- 1.2.8 -->
	<span class="version">1.2.8</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '2 May, 2023' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus Pro (PRO)
		• Compatibility: Elementor 3.12.0
		• Fixed: Deprecated functions
		• Fixed: Some minor issues
	</div>

	<!-- 1.2.7 -->
	<span class="version">1.2.7</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '9 February, 2023' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus Pro (PRO)
		• Improvement: Plugin Manager (PRO)
		• Fixed: Dark mode style
		• Fixed: Some minor issues
	</div>

	<!-- 1.2.6 -->
	<span class="version">1.2.6</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '12 January, 2023' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Compatibility: Elementor 3.10.0
		• Fixed: Some minor issues
	</div>

	<!-- 1.2.5 -->
	<span class="version">1.2.5</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '22 December, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: New Demo named Shop
		• Added: Custom CSS to page options
		• Updated: dashboard design
		• Updated: dashboard design
		• Compatibility: With ShopPress
		• Update: Default container size
		• Update: Default Theme styles
		• Updated: Importer
		• Updated: Default builders
		• Updated: Importer
		• Fixed: PHP fatal error when kata theme is not installed
		• Fixed: grid.css file did now load in Elementor editor
		• Fixed: Js error in theme-scripts.js
		• Fixed: PHP error header already sent
		• Fixed: Post share icons parent hover
		• Fixed: Some minor issues
	</div>

	<!-- 1.2.4 -->
	<span class="version">1.2.4</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '31 October, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Updated: Default Builders
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus Pro (PRO)
		• Update: License activation
		• Update: Demo Importer
		• Update: Presets
		• Update: Template Manager
		• Improvement: Lazyload
		• Compatibility: Elementor 3.8.0
		• Compatibility: Login widget with iThemes security lockout
		• Fix: Customizer search styling issue in firefox
		• Fix: Styling issue kata icon in WP menu
		• Fix: No SVG file selected
		• Fix: Lazyload did not work in the Elementor editor
		• Fix: Image dimensions don't print when using a .svg file
		• Fix: widgets Icon didn't show well in Firefox
		• Fix: Rollback
	</div>

	<!-- 1.2.3 -->
	<span class="version">1.2.3</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '10 October, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Updated: Importer and api
		• Compatiblity: Elementor 3.7
		• Improvement: Roleback
		• Fixed: Elementor icon manager
		• Fixed: Kata Elementor Presets
	</div>

	<!-- 1.2.2 -->
	<span class="version">1.2.2</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '14 Sep, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Fixed: PHP fatal error
	</div>

	<!-- 1.2.1 -->
	<span class="version">1.2.1</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '12 Sep, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Modified: Theme Options order item
		• Improvement: Importer notices
		• Improvement: Search widget
		• Improvement: login widget Ui
		• Fixed: PHP error in cart widget
		• Fixed: Some minor issues
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus
		• Updated: Kata Plus Pro (PRO)
	</div>

	<!-- 1.2.0 -->
	<span class="version">1.2.0</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '15 May, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Portfolio tags elementor widget
		• Compatibility: WPML
		• Compatibility: Polylang
		• Compatibility: WordPress 6.0
		• Compatibility: PHP 8.1.12
		• Improvement: Builders, Possibility to add multiple builders (Multi Header, Footer, ...)
		• Improvement: Fast Mode
		• Updated: Language File
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus
		• Updated: Kata Plus Pro (PRO)
		• Updated: Nav menu exporter
		• Fixed: Carousels in RTL sites Fixed:
		• Fixed: Transparent header
		• Fixed: Fatal error of thumbnail generator in PHP 8.0.14
		• Fixed: Some minor issues
	</div>

	<span class="version">1.1.10</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '5 March, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Compatibility: WordPress 5.9
		• Compatibility: WooCommerce 6.0.0
		• Compatibility: Customizer search with WordPress 5.9
		• Improvement: Customizer search style
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus
		• Updated: Kata Plus Pro (PRO)
		• Fixed: WooCommerce overlapping checkout field
		• Fixed: PhotoShut undefined variable PHP warning
		• Fixed: Chat Widget in rtl admin
		• Fixed: Presets don't show
		• Fixed: Template manager can not import template
	</div>

	<!-- 1.1.9 -->
	<span class="version">1.1.9</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '2 February, 2022' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: installation notices for the pro version and when Elementor is not active
		• Improved: blog posts widget
		• Fixed: builder fatal errors when Elementor is not activated
		• Fixed: importer builder
		• Fixed: fatal error when the host does not support ZIP extension
		• Fixed: CSS error in Styler output
		• Fixed: some minor issues
		• Remove: some unused CSS
	</div>

	<!-- 1.1.8 -->
	<span class="version">1.1.8</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '23 December, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Compatibility: WordPress 5.8
		• Compatibility: Elementor 3.5.2
		• Compatibility: Elementor Pro 3.5.2
		• Added: Breadcrumb to theme options > pages
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Updated: Kata Plus
		• Updated: Kata Plus Pro (PRO)
		• Fixed: Styler confilicts with elementor 3.5
	</div>
	<!-- 1.1.7 -->
	<span class="version">1.1.7</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '6 December, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Improvement: Protfolio Image
		• Improvement: Importer
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider LayerSlider plugin (PRO)
		• Updated: Slider Revolution plugin (PRO)
		• Fixed: Confilicts between the Elementor motion effects and styler translate options
		• Fixed: Full site Editor
		• Fixed:  to theme options > pages not translatable
		• Fixed: Mixed content in admin Improvement: Show type of cURL error type in importer
		• Fixed: Lazyload carousels widgets
		• Fixed: Fatal error elementor presets
	</div>
	<!-- 1.1.6 -->
	<span class="version">1.1.6</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '9 November, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Alternative ZipArchive
		• Added: Portfolio Archive Builder
		• Updated: Essential Grid to 3.0.13
		• Updated: FileBird to 4.9.3
		• Updated: Quform to 2.15.0
		• Updated: Slider Revolution to 6.5.9
		• Updated: Layer Slider to 6.11.9
		• Updated: Advanced Custom Fields PRO to 5.10.2
		• Updated: Kirki Framework
		• Modified: Portfolio page slug
		• Modified: Kata Control Panel Welcome page
		• Compatibility: PHP 8
		• Fixed: Conflicts between "Advanced Custom Fields Pro" and "Kata" demo importer
		• Fixed: Fatal error, Call to undefined function finfo_open()
		• Fixed: PHP notices on Archive Posts elementor widget
		• Fixed: Filters not worked on Portfolio elementor widget
		• Fixed: Wite screen after activation Kata Plus plugin
		• Fixed: Importer did not work in some host
		• Fixed: PHP notices on Blog Posts elementor widget
		• Fixed: PHP notices on Recent Posts elementor widget
		• Fixed: PHP notices on Related Posts elementor widget
	</div>
	<!-- 1.1.5 -->
	<span class="version">1.1.5</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '31 August, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: New demo named Environment
		• Added: New demo named GYM
		• Updated: Onclick demo import
		• Updated: Meta Box core
		• Fixed: PHP error on testimonial elementor widget
		• Fixed: Styler Conflicts with Elementor devices
		• Updated: Filebird Media Folders plugin (PRO)
	</div>
	<!-- 1.1.4 -->
	<span class="version">1.1.4</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '22 August, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Updated: Language file
		• Updated: Slider Revolution (Pro)
		• Fixed: Some RTL issues in Control Panel
		• Fixed: Nav Menu Walker
		• Fixed: Menu Icon Walker
		• Fixed: PHP fatal error on mkdir function
		• Fixed: Template manager can not be open (Pro)
		• Fixed: Booktable widget
		• Fixed: Content Slider widget
	</div>
	<!-- 1.1.3 -->
	<span class="version">1.1.3</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '17 August, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Widget for Load More text button on blog posts
		• Compatibility: Elementor 3.4
		• Improvement: Social media Elementor widget
		• Updated: Filebird Media Folders plugin (PRO)
		• Fixed: PHP notice in menu Elementor widget
		• Fixed: PHP fatal error when zip extention does not exist
		• Fixed: PHP fatal error, in WooCommerce Cart Widget
	</div>

	<!-- 1.1.2 -->
	<span class="version">1.1.2</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '8 August, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Object Position for styler
		• Added: LayerSlider
		• Added: Thumbnail Size for woocommerce
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider  (Pro) plugin (PRO)
		• Fixed: Customizer Woocommerce Option php notices
		• Fixed: Taxonomy filter for search widget
		• Fixed: Banner Widget Image crop functionality
		• Fixed: Post Featured Image Preview
		• Fixed: WooCommerce Styling issues
		• Fixed: Some styling issue in admin notices
		• Fixed: Some minor issues
	</div>
	<!-- 1.1.1 -->
	<span class="version">1.1.1</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '31 July, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Dark Mode for frontend (PRO)
		• Added: Taxonomy filter for search widget
		• Added: Descriptions for kata widget options
		• Added: Items for both desktop and tablet in testimonials widget
		• Added: Title animations for First posts in blog posts widgets
		• Updated: Kirki framework
		• Updated: Meta Box framework
		• Updated: Advanced Custom Fields Pro plugin (PRO)
		• Updated: Essential Grid plugin (PRO)
		• Updated: Filebird Media Folders plugin (PRO)
		• Updated: Quform plugin (PRO)
		• Updated: Slider  (Pro) plugin (PRO)
		• Improvement: Show related posts widget
		• Improvement: Woocommerce default style
		• Improvement: Theme base style
		• Improvement: Menu widget
		• Modified: Fonts manager output from footer to header
		• Fixed: Styler of icons in socials widget
		• Fixed: The search button icon is now clickable
		• Fixed: Styling issues in Contorl panel
		• Fixed: PHP notice for search widget
		• Fixed: Default value of minify js and css
		• Fixed: Styling issues in Contorl panel
		• Fixed: PHP notice for search widget
		• Fixed: Default value of minify js and css
	</div>
	<!-- 1.1.0 -->
	<span class="version">1.1.0</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '19 July, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: DynamicTags for Elementor (PRO)
		• Added: Photoshut photo editor (PRO)
		• Added: Performance Options (PRO)
		• Added: Thumbnails for post carousel
		• Added: Seprator option for categories in post metadata widget (PRO)
		• Compatibility: PHP 8
		• Improvement: Next and Previous Posts (PRO)
		• Improvement: Loading speeds in backend
		• Improvement: Superfish
		• Improvement: menu widget
		• Improvement: Styler performance
		• Fixed: Hamburger Menu
		• Fixed: Blog Posts Columns styling issues
		• Fixed: Show/Hide Page titles in customizer > pages
		• Fixed: Header Transparent background
		• Fixed: fatal error when elementor not installed
		• Fixed: PHP Notice In blog post widget
		• Fixed: Some minor issues
	</div>
	<!-- 1.0.7 -->
	<span class="version">1.0.7</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '21 June, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Animation Options for styler (Pro)
		• Added: Video Carousel (Pro)
		• Added: Search for Customizer
		• Added: Like icon for blog posts (Pro)
		• Added: Loadmore Button for blog posts
		• Improvement: Lazyload (Pro)
		• Improvement: Description of Options
		• Improvement: Prallax Motion Effects (Pro)
		• Improvement: Templates manager (Pro)
		• Improvement: Related posts widget (Pro)
		• Improvement: Login widget (Pro)
		• Updated: Kata icon pack
		• Updated: Advanced Custom Fields Pro
		• Updated: Essential Grid
		• Updated: Filebird pro
		• Updated: Quform
		• Updated:  (Pro) Slider
		• Updated: POT File
		• Updated: Meta Box
		• Fixed: Shop Elementor Widget (Pro)
		• Fixed: HTML validate in blog widgets
		• Fixed: Template Manager In Single Builder
		• Fixed: Some minor issues
		• Fixed: HTML Issue in date elementor widget
		• Fixed: minor issue in player widget
		• Fixed: HTML errors in SVG icons
		• Fixed: Dark Mode styling issue
		• Fixed: WooCommerce Mini Cart CSS issue (Pro)
		• Fixed: WooCommerce my account page styling issue (Pro)
	</div>
	<!-- 1.0.6 -->
	<span class="version">1.0.6</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '5 May, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Post excerpt widget
		• Added: Sidebar options for blog pages
		• Added: Columns gap option to customizer > container
		• Added: Icon for post formats
		• Updated: Language File
		• Compatibility: Elementor 3.2.3
		• Compatibility: WP socials
		• Improvement: Importer
		• Improvement: Page styling options
		• Improvement: Blog posts elementor widgets
		• Improvement: CSS Minifier
		• Improvement: Elementor Menu Widgets
		• Fixed: Image full size width and height when using lazyload
		• Fixed: Banner link widget
		• Fixed: HTML Validator problems
		• Fixed: admin icons styling issues
		• Fixed: Minor issue in post format icons
		• Fixed: Tablet landscape responsive problem
		• Fixed: Background image none option in styler
		• Fixed: Some minor styling issues in importer
		• Removed: Lazyload functions from backend (when editing elementor page)
	</div>
	<!-- 1.0.5 -->
	<span class="version">1.0.5</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '27 April, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Post excerpt widget
		• Added: Audio Player for Pro version
		• Added: Image Lazyload
		• Improvement: Login modal script
		• Improvement: Toggle Content Widget
		• Improvement: Hamburger Menu Widget
		• Improvement: Carousel widgets
		• Improvement: Login Widget
		• Improvement: Search modal script
		• Improvement: Social share sticky
		• Improvement: Search widget
		• Improvement: Testimonial arrow styler
		• Improvement: Elementor Menu Widgets
		• Compatibility: PHP 8
		• Compatibility: Elementor 3.2.0
		• Modified: Default Search form in search page
		• Modified: Location of builders' header option to customizer > pages
		• Updated: Advanced Custom Fields Pro
		• Updated: Essential Grid
		• Updated: Filebird pro
		• Updated: Quform
		• Updated:  (Pro) Slider
		• Fixed: OwlCarousel not showing navigation
		• Fixed: Social Share Sticky
		• Fixed: Responsive Breakpoints between laptop and tablet landscape
		• Fixed: Importer remove posts
		• Fixed: Login Toggle modal animation
		• Fixed: CSS of postmetadata widget not loading in single builder
		• Fixed: Elementor Frontend editor tablet and tablet landscape breakpoints
		• Fixed: Elementor Editore View Port
		• Fixed: Important not working in margin fields
		• Fixed: Login modal
		• Fixed: Header Show/Hide Option
		• Fixed: Styler of image in icon box
		• Fixed: Search widget conditions
		• Fixed: Search widget icon output
		• Fixed: Styler mini styling issue
		• Fixed: Preloader Styling issue
		• Fixed: Blog functions
		• Fixed: Mega menu options
		• Fixed: Customizer importer
		• Fixed: Admin menu in control panel
		• Fixed: Some minor styling issues in importer
		• Fixed: Like functionality
		• Fixed: HTML Validator problems
		• Fixed: Presets
		• Fixed: Next and previous widget
		• Fixed: Unclosed tag on blog widgets
		• Fixed: Some minor issues
	</div>
	<!-- 1.0.4 -->
	<span class="version">1.0.4</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '7 March, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: Number of items between Desktop and Tablet in widgets that support Carousel
		• Added: Header options for posts
		• Added: Header options for builders search, author, archive, blog, and 404
		• Added: Overlay option for team member thumbnail
		• Added: Widget simple gallery
		• Added: Author page title options to customizer (theme options)
		• Added: Content tab to Post Featured Image widget
		• Added: The ability to close the hamburger menu by pressing the Esc key
		• Added: The ability to share posts in post widgets
		• Added: Widget Template Loader
		• Added: Help box to plugin dashboard
		• Added: Blockquote to theme option > advanced styling option
		• Added: Icon position for the button widget
		• Added: Icon position for subscribe widget
		• Improved: Recent posts widget
		• Improved: Styler color picker
		• Improved: Next and previous post widget
		• Improved: Open WordPress navigation bar in the plugin control panel
		• Improved: Widget and widget option labels
		• Compatibility: Elementor 3.1.0
		• Modified: Food menu widget icons
		• Modified: Transparent header control option to the dropdown
		• Modified: Subscribe widget name
		• Updated: One-click demo importer
		• Fixed: Comment templates not loading on the backend
		• Fixed: Comment form not submitting due to JS error
		• Fixed: Name of Post Comments widget
		• Fixed: Displaying hamburger menu icon in the modal view
		• Fixed: Overlapping of the close icon and search form in the search widget in Modal type
		• Fixed: Blog widgets pagination
		• Fixed: Loading time for pages with blog widgets
		• Fixed: Responsive breakpoints
		• Fixed: The styling icons for Pricing Plan widget items
		• Fixed: Fonts manager text preview
		• Fixed: JS Error when using Elementor responsive buttons
		• Fixed: PHP notice and warning in license activation
		• Fixed: SEO analytics widget
		• Fixed: Incompatibility of responsive breakpoints on backend and frontend
		• Fixed: Styling issue in image control
		• Fixed: Styler background-position control
		• Fixed: Carousel sizes
		• Fixed: Unable to choose a custom icon
		• Fixed: removed srcset from thumbnails that were custom sized
		• Fixed: Revert of column size after a change in scale
		• Fixed: Header dark transparency
		• Fixed: Login modal CSS issue
		• Fixed: Styler CSS generator
		• Fixed: Some minor CSS issues in the admin
		• Fixed: Hide header in sticky header builder
		• Fixed: Thumbnail generator
		• Fixed: Importer wouldn't download demo file in PHP 5.6
		• Fixed: Alternative fonts
		• Fixed: Add custom icon set
		• Fixed: Widget post title
		• Fixed: Widget post metadata
		• Fixed: Instagram CSS issue
		• Fixed: Blog post widgets container size
		• Fixed: Blog post widgets avatar thumbnail
		• Fixed: Default value transparency for dark header
	</div>
	<!-- 1.0.3 -->
	<span class="version">1.0.3</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '3 January, 2021' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: alternative web service for demo importer
		• Added: subscribe widget
		• Added: fast demos to demo importer
		• Added: fast Free demos to demo importer
		• Added: search tool to demo importer
		• Added: separator option to  to theme options > pages Improved: support of PHP 5.6 and higher
		• Improved: demo importer style
		• Updated: language file kata-plus.pot
		• Modified: default style of the blog
		• Modified: label of Stroke and Fill color option in styler
		• Modified: Help Page Title in the control panel
		• Modified: change icon of address, email, phone, and single testimonial Elementor widget
		• Fixed: Woocommerce styles
		• Fixed: wrong text domains
		• Fixed: some styling issues in dark mode
		• Fixed: unsanitized data in the importer
		• Fixed: styler background image preview•
		Fixed: importer dark mode styling issues
		• Fixed: wrong spelling in the customizer
		• Fixed: After/Before content output
		• Fixed: wrong spelling in Elementor widgets
		• Fixed: mega menu Full-width option
		• Fixed: wrong spelling page options
		• Fixed: Preview of demos in fast mode
		• Fixed: license activation notices
		• Fixed: login widget clickable issue
		• Fixed: some styling issues in fast mode
		• Fixed: PHP notice in button Elementor widget
		• Fixed: prevent to load styler in tgm page
		• Fixed: PHP notice in counter Elementor widget
		• Fixed: comparison slider image output
		• Removed: 7 stroke icon set from the free version
	</div>
	<!-- 1.0.2 -->
	<span class="version">1.0.2</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '13 December, 2020' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: new style to Woocommerce cart, checkout, and single product page
		• Added: new styling options to customize > pages
		• Improved: blog post, archive post, author page, and search page widget
		• Compatibility WordPress 5.6
		• Compatibility Elementor 3.0.14
		• Fixed: sticky header
		• Fixed: google font API key (Access denied)
		• Fixed: styling in Metabox sections
		• Fixed: Woocommerce cart widget
		• Fixed: transparent header styling issue
		• Fixed: alternative fonts
	</div>
	<!-- 1.0.1 -->
	<span class="version">1.0.1</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '7 December, 2020' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Added: installation notices for the pro version and when Elementor is not active
		• Improved: blog posts widget
		• Fixed: builder fatal errors when Elementor is not activated
		• Fixed: importer builder
		• Fixed: fatal error when the host does not support ZIP extension
		• Fixed: CSS error in Styler output
		• Fixed: some minor issues
		• Remove some unused CSS
	</div>
	<!-- 1.0.0 -->
	<span class="version">1.0.0</span> – <span class="date"><?php echo esc_html( date_format( date_create_from_format( 'j F, Y', '4 December, 2020' ), get_option( 'date_format' ) ) ) . "\n"; ?></span>
	<div class="change-list">
		• Initial Release
	</div>
</pre>
